import Foundation
struct Item: Decodable { let label:String; let root:JSONValue }
let out="/tmp/suji-b3-implementation-review"
func at(_ root:JSONValue,_ path:String)->JSONValue? { ReadingVerificationEvidence.pointer(path,in:root) }
func str(_ root:JSONValue,_ path:String)->String { if case let .string(s)=at(root,path){return s};return "" }
func arr(_ root:JSONValue,_ path:String)->[JSONValue] { if case let .array(a)=at(root,path){return a};return [] }
func edit(_ root:JSONValue,_ path:String,_ replacement:JSONValue?)->JSONValue {
 let keys=path.split(separator:"/").map(String.init)
 func go(_ v:JSONValue,_ i:Int)->JSONValue { switch v {case var .object(o):if i==keys.count-1 {o[keys[i]]=replacement}else{o[keys[i]]=go(o[keys[i]] ?? .null,i+1)};return .object(o);case var .array(a):let n=Int(keys[i])!;if i==keys.count-1 {if let r=replacement{a[n]=r}else{a.remove(at:n)}}else{a[n]=go(a[n],i+1)};return .array(a);default:return v} };return go(root,0)
}
func ctx(_ root:JSONValue)throws->ToolContext {try ToolContext(birth:nil,engineRevision:str(root,"/provenance/engineRevision"),referenceDate:ISO8601DateFormatter().date(from:str(root,"/castTime").replacingOccurrences(of:".000Z",with:"Z"))!,mode:"起卦")}
func render(_ root:JSONValue)throws->LiuyaoReferenceReading.Report? {let c=try ctx(root);return LiuyaoReferenceReading.render(receipts:[ToolReceipt(callID:"independent",name:"cast_liuyao",arguments:[:],output:ReadingVerificationEvidence.encoded(root),context:c)],context:c)}
@main struct Probe {
 static func main() async throws {
  var failures:[String]=[],rendered=0,fields=0,candidateSections=0,roleSections=0,allMoving=0,staticClash=0,maxBytes=0,maxUTF16=0,calendarRoot:JSONValue?,firstRoot:JSONValue?,transportSamples:[JSONValue]=[]
  let data=try String(contentsOfFile:out+"/bundle-fixtures.ndjson",encoding:.utf8)
  for (index,line) in data.split(separator:"\n").prefix(1280).enumerated() {
   let item=try JSONDecoder().decode(Item.self,from:Data(line.utf8));let root=item.root;if firstRoot==nil{firstRoot=root};if !arr(root,"/roleRelations/unsupportedCandidates").isEmpty {calendarRoot=root};if index%128==0{transportSamples.append(root)}
   let n=arr(root,"/lines").filter{at($0,"/isChanging") == true}.count
   let clash=arr(root,"/lines").contains{at($0,"/isChanging") == false && at($0,"/context/day/clash") == true}
   if n==6{allMoving+=1};if clash{staticClash+=1}
   guard let report=try render(root) else{failures.append("nil:"+item.label);continue};rendered+=1
   for section in report.sections {for f in section.evidence{fields+=1;if at(root,f.pointer) != f.value || f.toolCallID != "independent"{failures.append("evidence:"+item.label+":"+f.pointer)}}}
   let ids=report.sections.map(\.id);let roles=report.sections.filter{$0.id.hasPrefix("roles-")};roleSections+=roles.count
   for candidate in arr(root,"/yongShen/candidates") {let id=str(candidate,"/id");candidateSections+=1;if ids.filter({$0=="roles-"+id}).count != 1{failures.append("candidate:"+item.label+":"+id)}}
   if n==6 && (report.text.contains("暗动") || roles.contains{$0.text.contains("静爻日冲效力")}){failures.append("allMovingDark:"+item.label)}
   for role in roles where role.id != "roles-unavailable" && !role.text.contains("日月参考") {
    if role.text.contains("静爻日冲效力") != clash {failures.append("clashScope:"+item.label)}
    for f in role.evidence where f.pointer.hasSuffix("/context") {if f.value != at(root,f.pointer){failures.append("context:"+item.label)}}
    if !role.text.contains("不能据此确定吉凶"){failures.append("conclusion:"+item.label)}
   }
   let full=ReadingVerificationEvidence.encoded(root);maxBytes=max(maxBytes,full.utf8.count);maxUTF16=max(maxUTF16,full.utf16.count)
   if index%1024==0{print("checked \(index)")}
  }
  var sourceReports:[String:String]=[:],sourceRoots:[String:JSONValue]=[:]
  for line in try String(contentsOfFile:out+"/source-case-receipts.ndjson",encoding:.utf8).split(separator:"\n") {let item=try JSONDecoder().decode(Item.self,from:Data(line.utf8));sourceRoots[item.label]=item.root;if let report=try render(item.root){sourceReports[item.label]=report.text;try report.text.write(toFile:out+"/"+item.label+".txt",atomically:true,encoding:.utf8)}else{failures.append("source-nil:"+item.label)}}
  let root=sourceRoots["ch10-daguo-ding"]!,rp="/roleRelations",gp=rp+"/groups/0",sourceIndex=arr(root,"/ruleSources").firstIndex{str($0,"/id")=="liuyao-candidate-roles-v1"}!,sp="/ruleSources/\(sourceIndex)"
  var mutations:[(String,JSONValue)]=[]
  func mutate(_ name:String,_ path:String,_ value:JSONValue?){mutations.append((name,edit(root,path,value)))}
  mutate("omit-static-yuan",gp+"/yuanPositions",[5]);mutate("changed-only-chou",gp+"/chouPositions",[6]);mutate("wrong-role-element",gp+"/elements/yuan","火")
  mutate("static-in-pair",gp+"/jiYuanMovingPairs",[["jiPosition":6,"yuanPosition":3],["jiPosition":6,"yuanPosition":5]])
  mutate("missing-pair",gp+"/jiYuanMovingPairs",[]);mutate("duplicate-pair",gp+"/jiYuanMovingPairs",[["jiPosition":6,"yuanPosition":5],["jiPosition":6,"yuanPosition":5]])
  mutate("wrong-target-id",gp+"/candidateRefs/0/id","fake");mutate("wrong-target-object",gp+"/candidateRefs/0/objectPath","/lines/5/changed");mutate("borrow-target-context",gp+"/candidateRefs/0/contextPath","/lines/2/context")
  mutate("missing-group",rp+"/groups",[]);mutate("duplicate-group",rp+"/groups",.array(arr(root,rp+"/groups")+arr(root,rp+"/groups")))
  mutate("wrong-inspected",rp+"/inspectedOriginalPaths",["/lines/0"]);mutate("wrong-source-id",rp+"/sourceId","other");mutate("wrong-source-version",sp+"/version","2");mutate("wrong-source-url",sp+"/references/0/url","https://example.com/");mutate("wrong-source-hash",sp+"/references/1/sha256",String(repeating:"0",count:64).json)
  mutate("role-without-source",sp,nil);mutate("source-without-role",rp,nil);mutate("outcome-true",rp+"/outcomeEstablished",true);mutate("missing-unresolved",rp+"/unresolved",[]);mutate("wrong-assessment",rp+"/assessmentStatus","established")
  mutate("invent-calendar-support",rp+"/unsupportedCandidates",[["id":.string(str(root,"/yongShen/candidates/0/id")),"objectPath":"/lines/3","reason":"calendar-target-outside-line-role-scope"]])
  let cal=try JSONDecoder().decode(Item.self,from:Data(contentsOf:URL(fileURLWithPath:out+"/calendar-fixture.json"))).root;if try render(cal)==nil{failures.append("calendar-valid-rejected")};for (name,path,value) in [("calendar-wrong-object",rp+"/unsupportedCandidates/0/objectPath",JSONValue.string("/lines/0")),("calendar-wrong-reason",rp+"/unsupportedCandidates/0/reason",JSONValue.string("supported")),("calendar-wrong-id",rp+"/unsupportedCandidates/0/id",JSONValue.string("fake")),("calendar-missing",rp+"/unsupportedCandidates",JSONValue.array([]))] {mutations.append((name,edit(cal,path,value)))}
  for (name,r) in mutations {if try render(r) != nil {failures.append("accepted-mutation:"+name)}}
  let legacy=edit(edit(root,sp,nil),rp,nil);if try render(legacy)==nil{failures.append("legacy-rejected")}
  // Independently exercise exact-argument projection, per-call authentication and replay.
  let question=String(repeating:"独立核对盘面与保留完整回执。",count:100),q=JSONValue.string(question)
  var projectedCases=0,replayCases=0,authChecks=0,transportMaxBytes=0
  for (index,original) in transportSamples.enumerated() {
   let r=edit(original,"/question",q),full=ReadingVerificationEvidence.encoded(r),context=try ctx(r),id="transport-\(index)"
   let call=ChatToolCall(id:id,name:"cast_liuyao",arguments:["question":q]);let before=[ChatMessage.assistantToolCalls([call])]
   let projected=NatalEvidenceProjection.output(full,name:"cast_liuyao",delivered:before,callID:id)
   let decoded=try JSONDecoder().decode(JSONValue.self,from:Data(projected.utf8)),restored=edit(edit(decoded,"/questionFromArguments",nil),"/question",q)
   if restored != r || at(decoded,"/question") != nil || str(decoded,"/questionFromArguments/toolCallID") != id{failures.append("projection:\(index)")};projectedCases+=1;transportMaxBytes=max(transportMaxBytes,projected.utf8.count)
   let receipt=ToolReceipt(callID:id,name:call.name,arguments:call.arguments,output:full,evidence:[id],context:context),result=ChatMessage.toolResult(.init(callID:id,output:projected))
   let auth:[(Bool,[ChatMessage])]=[(true,before+[result]),(false,[result]),(false,[.assistantToolCalls([.init(id:"wrong",name:call.name,arguments:call.arguments)]),result]),(false,[.assistantToolCalls([.init(id:id,name:call.name,arguments:["question":"changed"])]),result]),(false,[.assistantToolCalls([.init(id:id,name:"setup_qimen",arguments:call.arguments)]),result]),(false,before+before+[result])]
   for(expected,messages) in auth {authChecks+=1;if NatalEvidenceProjection.wasDelivered(receipt,in:messages) != expected{failures.append("auth:\(index)")}}
   var entry=ConversationEntry(role:"user",text:question);entry.toolReceipts=[receipt];let replay=ReadingPrompt.history(from:[entry],currentUserID:entry.id,context:context)
   if replay.first(where:{$0.role == .tool})?.content != projected || receipt.output != full{failures.append("replay:\(index)")};replayCases+=1
   if projected.utf16.count>32_000 || projected.utf8.count>60_000{failures.append("capacity:\(index)")}
  }
  // Threshold includes multibyte text; an exact duplicate at <=600 bytes remains inline.
  for bytes in [599,600,601] {let s=String(repeating:"x",count:bytes),r=edit(firstRoot!,"/question",s.json),full=ReadingVerificationEvidence.encoded(r),call=ChatToolCall(id:"threshold",name:"cast_liuyao",arguments:["question":s.json]);let projected=NatalEvidenceProjection.output(full,name:call.name,delivered:[.assistantToolCalls([call])],callID:call.id);if (projected != full) != (bytes>600){failures.append("threshold:\(bytes)")}}
  let report:[String:Any] = ["records":rendered,"evidenceFields":fields,"candidateSections":candidateSections,"roleSections":roleSections,"allMovingReports":allMoving,"reportsWithStaticDayClash":staticClash,"sourceReports":sourceReports.keys.sorted(),"mutations":mutations.map{$0.0},"mutationsRejected":mutations.count-failures.filter{$0.hasPrefix("accepted-mutation:")}.count,"legacyFiveSourceAccepted":(try render(legacy)) != nil,"fullReceiptMaxUTF8":maxBytes,"fullReceiptMaxUTF16":maxUTF16,"transportCases":projectedCases,"transportAuthenticationChecks":authChecks,"replayCases":replayCases,"transportMaxUTF8":transportMaxBytes,"failures":failures]
  let result=try JSONSerialization.data(withJSONObject:report,options:[.prettyPrinted,.sortedKeys,.withoutEscapingSlashes]);try result.write(to:URL(fileURLWithPath:out+"/native-report.json"));print(String(decoding:result,as:UTF8.self))
 }
}
extension String {var json:JSONValue{.string(self)}}
