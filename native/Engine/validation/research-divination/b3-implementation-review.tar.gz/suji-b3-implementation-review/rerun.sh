#!/bin/bash
set -euo pipefail
review_dir="$(cd "$(dirname "$0")" && pwd)"
review_repo="${1:-/Users/xiaqobenwang/Documents/SUJI}"
if [[ "$review_dir" != /tmp/suji-b3-implementation-review ]]; then
  echo 'Extract this archive under /tmp so the Swift artifact paths remain /tmp/suji-b3-implementation-review.' >&2
  exit 2
fi
cd "$review_repo"
node "$review_dir/engine-probe.cjs" "$review_repo"
node "$review_dir/generate-bundle-fixtures.cjs"
node "$review_dir/generate-calendar-fixture.cjs"
swiftc -O -parse-as-library $(rg --files native/Core/Sources/SujiCore -g '*.swift') "$review_dir/native-probe.swift" -o "$review_dir/native-probe"
"$review_dir/native-probe"
swiftc -parse-as-library $(rg --files native/Core/Sources/SujiCore -g '*.swift') "$review_dir/transport-orchestrator.swift" -o "$review_dir/transport-orchestrator"
"$review_dir/transport-orchestrator"
python3 - <<'PY'
import json
from pathlib import Path
root=Path('/tmp/suji-b3-implementation-review')
assert not json.loads((root/'engine-report.json').read_text())['mismatches']
assert not json.loads((root/'native-report.json').read_text())['failures']
assert not json.loads((root/'transport-orchestrator-report.json').read_text())['failures']
print('Independent bounded review: all checks passed.')
PY
