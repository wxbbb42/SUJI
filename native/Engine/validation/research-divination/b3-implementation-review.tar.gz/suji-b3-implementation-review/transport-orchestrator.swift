import Foundation
@main struct Probe {
 static func main() async throws {
 let out="/tmp/suji-b3-implementation-review",line=try String(contentsOfFile:"/tmp/suji-b3-implementation-review/bundle-fixtures.ndjson",encoding:.utf8).split(separator:"\n").first!,envelope=try JSONDecoder().decode(JSONValue.self,from:Data(line.utf8));var object: [String:JSONValue];guard case let .object(r)=ReadingVerificationEvidence.pointer("/root",in:envelope)else{fatalError()};object=r
 let question=String(repeating:"请保留原问题以及完整盘面记录。",count:100);object["question"] = .string(question)
 let full=ReadingVerificationEvidence.encoded(JSONValue.object(object)),context=try ToolContext(birth:nil,engineRevision:"independent",referenceDate:Date(timeIntervalSince1970:1707019200),mode:"起卦")
 let args:JSONValue=["question":.string(question)],calls=[ChatToolCall(id:"a",name:"cast_liuyao",arguments:args),ChatToolCall(id:"b",name:"cast_liuyao",arguments:["question":"planner drift must use first question"])]
 let definition=ChatToolDefinition(name:"cast_liuyao",description:"independent",parameters:["type":"object","properties":["question":["type":"string"]],"required":["question"]])
 var rounds=0,executions=0,persisted:[ToolReceipt]=[]
 let orchestrator=ToolOrchestrator(complete:{_,_ in rounds+=1;return rounds==1 ? .toolCalls(calls) : .text("ready")},execute:{_ in executions+=1;return .init(output:full,evidence:["facts"])},persistReceipt:{persisted.append($0)})
 let result=try await orchestrator.run(history:[ChatMessage(role:.user,content:question)],definitions:[definition],context:context)
 var failures:[String]=[]
 if executions != 1 || persisted.count != 1 || result.receipts.count != 2 {failures.append("cast/persistence count")}
 if !result.receipts.allSatisfy({$0.output==full && $0.arguments==args}){failures.append("immutable receipt / corrected arguments")}
 let outputs=result.messages.filter{$0.role == .tool}.map{$0.content!}
 for(index,output) in outputs.enumerated(){var o:[String:JSONValue];guard case let .object(r)=try JSONDecoder().decode(JSONValue.self,from:Data(output.utf8))else{fatalError()};o=r;if ReadingVerificationEvidence.pointer("/questionFromArguments/toolCallID",in:.object(o)) != .string(calls[index].id){failures.append("own-call projection")};o.removeValue(forKey:"questionFromArguments");o["question"] = .string(question);if .object(o) != JSONValue.object(object){failures.append("lossy chart")}}
 var entry=ConversationEntry(role:"user",text:question);entry.toolReceipts=persisted;let replay=ReadingPrompt.history(from:[entry],currentUserID:entry.id,context:context)
 var retryRounds=0,recasts=0
 let retry=ToolOrchestrator(complete:{_,_ in retryRounds+=1;return retryRounds==1 ? .toolCalls([.init(id:"c",name:"cast_liuyao",arguments:["question":"another planner drift"])]) : .text("ready")},execute:{_ in recasts+=1;return .init(output:"{}")})
 let retried=try await retry.run(history:replay,definitions:[definition],cachedReceipts:persisted,context:context)
 if recasts != 0 || retried.receipts.first?.arguments != args || retried.receipts.first?.output != full || retried.evidence != ["facts"]{failures.append("retry chart/evidence")}
 if let receipt=retried.receipts.first,!NatalEvidenceProjection.wasDelivered(receipt,in:retried.messages){failures.append("retry delivered authentication")}
 let report:[String:Any]=["initialExecutions":executions,"initialReceipts":result.receipts.count,"persistedReceipts":persisted.count,"retryExecutions":recasts,"retryEvidence":retried.evidence,"messageBytes":outputs.map{$0.utf8.count},"failures":failures]
 let data=try JSONSerialization.data(withJSONObject:report,options:[.prettyPrinted,.sortedKeys]);try data.write(to:URL(fileURLWithPath:out+"/transport-orchestrator-report.json"));print(String(decoding:data,as:UTF8.self))
 }
}
